# GBT Mainnet Streamlit App

This is a basic Streamlit app starter for the GBT Mainnet Monorepo project.

## Running locally

```sh
pip install -r requirements.txt
streamlit run app.py
```

## Deploying on Streamlit Cloud

1. Push this repo to GitHub.
2. Visit [Streamlit Cloud](https://streamlit.io/cloud) and connect your repo.
3. Select `app.py` as the entrypoint.
4. Enjoy your deployed app!